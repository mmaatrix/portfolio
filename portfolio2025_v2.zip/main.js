// ===== Helpers =====
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// ===== Year =====
$("#year").textContent = new Date().getFullYear();

// ===== AOS init =====
if (window.AOS) {
  AOS.init({
    once: true,
    offset: 80,
    duration: 650,
    easing: "ease-out-cubic",
  });
}

// ===== Mobile nav =====
const navToggle = $("#navToggle");
const mobileNav = $("#mobileNav");

if (navToggle && mobileNav) {
  navToggle.addEventListener("click", () => {
    mobileNav.classList.toggle("hidden");
    const isOpen = !mobileNav.classList.contains("hidden");
    navToggle.setAttribute("aria-expanded", String(isOpen));
  });

  mobileNav.addEventListener("click", (e) => {
    if (e.target.matches("a")) {
      mobileNav.classList.add("hidden");
      navToggle.setAttribute("aria-expanded", "false");
    }
  });
}

// ===== Theme (Tailwind 'dark' class) =====
const themeToggle = $("#themeToggle");
const themeIcon = $("#themeIcon");
const root = document.documentElement;

function applyTheme(mode) {
  // mode: 'dark' | 'light'
  if (mode === "dark") root.classList.add("dark");
  else root.classList.remove("dark");

  localStorage.setItem("theme", mode);

  const isDark = mode === "dark";
  themeToggle?.setAttribute("aria-pressed", String(isDark));
  if (themeIcon) themeIcon.textContent = isDark ? "🌙" : "☀️";
}

const savedTheme = localStorage.getItem("theme");
applyTheme(savedTheme || "dark");

themeToggle?.addEventListener("click", () => {
  const isDark = root.classList.contains("dark");
  applyTheme(isDark ? "light" : "dark");

  if (window.Swal) {
    Swal.fire({
      toast: true,
      position: "top",
      timer: 1300,
      showConfirmButton: false,
      icon: "success",
      title: isDark ? "Light mode enabled" : "Dark mode enabled",
    });
  }
});

// ===== Project filtering =====
const chips = $$(".chip2025");
const projects = $$(".project2025");
const noResults = $("#noResults");

function setActiveChip(clicked) {
  chips.forEach((c) => c.classList.remove("is-active"));
  clicked.classList.add("is-active");
}

function filterProjects(tag) {
  let visible = 0;

  projects.forEach((p) => {
    const tags = (p.getAttribute("data-tags") || "").split(/\s+/);
    const show = tag === "all" || tags.includes(tag);
    p.style.display = show ? "" : "none";
    if (show) visible++;
  });

  noResults?.classList.toggle("hidden", visible !== 0);
}

chips.forEach((chip) => {
  chip.addEventListener("click", () => {
    setActiveChip(chip);
    filterProjects(chip.dataset.filter);
  });
});

// ===== Back to top =====
const backToTop = $("#backToTop");

function updateBackToTop() {
  if (!backToTop) return;
  if (window.scrollY > 600) backToTop.classList.remove("hidden");
  else backToTop.classList.add("hidden");
}
window.addEventListener("scroll", updateBackToTop);
updateBackToTop();

backToTop?.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ===== Contact form validation + SweetAlert2 =====
const form = $("#contactForm");

function setError(el, msg) {
  if (el) el.textContent = msg;
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

form?.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = $("#name").value.trim();
  const email = $("#email").value.trim();
  const message = $("#message").value.trim();

  const nameError = $("#nameError");
  const emailError = $("#emailError");
  const messageError = $("#messageError");
  const status = $("#formStatus");

  setError(nameError, "");
  setError(emailError, "");
  setError(messageError, "");
  if (status) status.textContent = "";

  let ok = true;

  if (name.length < 2) {
    setError(nameError, "Please enter your name (at least 2 characters).");
    ok = false;
  }
  if (!isValidEmail(email)) {
    setError(emailError, "Please enter a valid email address.");
    ok = false;
  }
  if (message.length < 10) {
    setError(messageError, "Please write a message (at least 10 characters).");
    ok = false;
  }
  if (!ok) return;

  // Demo success (no backend)
  if (window.Swal) {
    Swal.fire({
      icon: "success",
      title: "Message sent!",
      text: "Thanks — your message is validated and ready. (Demo: no backend connected.)",
      confirmButtonText: "OK",
    });
  } else {
    if (status) status.textContent = "Message sent (demo). Thanks!";
  }

  form.reset();
});
